//
//  SpeechTranscriber.swift
//  Velora
//
//  On-device speech recognition + speech activity + ONSET QUALITY (Easy Onset).
//  Offline-first (requiresOnDeviceRecognition = true).
//
//  ✅ Adds expected phrase matching (for auto-stop behavior in EasyOnsetView).
//  ✅ Adds rawRMS + optional file recording sink (for Rhythm playback recording).
//
//  Updated by Velora on 01/03/2026:
//  ✅ Fix for Swift Playgrounds / Mac App Preview crash:
//     - Robust, VALID AVAudioFormat selection for installTap
//     - Never uses 0 Hz or 0 channel formats
//     - Prefers native inputFormat when valid (most stable)
//

import Foundation
import Combine
import Speech
import AVFoundation

@MainActor
final class SpeechTranscriber: ObservableObject {
    
    // MARK: - Published
    @Published var transcript: String = ""
    @Published var isRecording: Bool = false
    @Published var isSpeaking: Bool = false
    @Published var audioLevel: Float = 0
    @Published var voicing: Float = 0
    @Published var rawRMS: Float = 0
    @Published var statusMessage: String? = nil
    @Published var isAuthorized: Bool = false
    @Published var supportsOnDevice: Bool = false
    
    // Onset outputs
    @Published var onsetScore: Int = 0
    @Published var onsetKind: OnsetMetrics.Kind = .unknown
    @Published var onsetVerdict: OnsetMetrics.Verdict = .notDetected
    @Published var onsetHint: String = "Start gently…"
    @Published var onsetConfidence: Float = 0.0
    @Published var onsetDebug: String? = nil
    
    // Expected phrase match flag
    @Published var didMatchExpectedPhrase: Bool = false
    
    // MARK: - Private
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private let recognizer: SFSpeechRecognizer?
    
    private let onsetAnalyzer = OnsetAnalyzer()
    
    private var currentSampleRate: Double = 44_100
    private let tapBufferSize: AVAudioFrameCount = 1024
    
    // Kinder speaking detection
    private let speakingThreshold: Float = 0.012
    
    private var expectedWords: [String] = []
    
    // MARK: - Matching Tunables
    private var lcsMatchRatio: Float = 0.70
    private var minimumMatchedWords: Int = 1
    
    // File recording
    private var recordURL: URL? = nil
    private var recordFile: AVAudioFile? = nil
    private var shouldRecordToFile: Bool = false
    
    init(locale: Locale = Locale(identifier: "en_US")) {
        self.recognizer = SFSpeechRecognizer(locale: locale)
        self.supportsOnDevice = recognizer?.supportsOnDeviceRecognition ?? false
    }
    
    // MARK: - Expected phrase API
    func setExpectedPhrase(_ text: String) { expectedWords = Self.words(from: text) }
    func resetExpectedMatch() { didMatchExpectedPhrase = false }
    
    func configureMatch(ratio: Float, minWords: Int = 1) {
        lcsMatchRatio = min(max(ratio, 0.40), 1.00)
        minimumMatchedWords = max(1, minWords)
    }
    
    // MARK: - File recording API
    func startFileRecording(to url: URL) {
        recordURL = url
        recordFile = nil
        shouldRecordToFile = true
    }
    
    func stopFileRecording() {
        shouldRecordToFile = false
        recordFile = nil
        recordURL = nil
    }
    
    // MARK: - Permissions
    func requestPermissions() async {
        let micGranted = await withCheckedContinuation { (c: CheckedContinuation<Bool, Never>) in
            AVAudioSession.sharedInstance().requestRecordPermission { granted in c.resume(returning: granted) }
        }
        
        let speechStatus = await withCheckedContinuation { (c: CheckedContinuation<SFSpeechRecognizerAuthorizationStatus, Never>) in
            SFSpeechRecognizer.requestAuthorization { status in c.resume(returning: status) }
        }
        
        let speechGranted = (speechStatus == .authorized)
        isAuthorized = micGranted && speechGranted
        
        if !micGranted {
            statusMessage = "Microphone permission is needed."
        } else if !speechGranted {
            statusMessage = "Speech Recognition permission is needed."
        } else {
            statusMessage = nil
        }
    }
    
    // MARK: - Control
    func resetTranscript() {
        transcript = ""
        didMatchExpectedPhrase = false
    }
    
    func resetOnset() {
        onsetScore = 0
        onsetKind = .unknown
        onsetVerdict = .notDetected
        onsetHint = "Start gently…"
        onsetConfidence = 0.0
        onsetDebug = nil
    }
    
    func start() {
        guard isRecording == false else { return }
        
        guard isAuthorized else {
            statusMessage = statusMessage ?? "Permissions are not granted yet."
            return
        }
        
        guard let recognizer, recognizer.isAvailable else {
            statusMessage = "Speech recognition is not available right now."
            return
        }
        
        supportsOnDevice = recognizer.supportsOnDeviceRecognition
        
        do {
            try configureSessionSafely()
        } catch {
            statusMessage = "Audio setup failed: \(error.localizedDescription)"
            stop()
            return
        }
        
        transcript = ""
        didMatchExpectedPhrase = false
        resetOnset()
        
        startEngineTapSafely()
        startRecognitionTask(recognizer: recognizer)
        
        isRecording = true
        statusMessage = nil
    }
    
    func stop() {
        task?.cancel()
        task = nil
        
        request?.endAudio()
        request = nil
        
        if audioEngine.isRunning { audioEngine.stop() }
        audioEngine.inputNode.removeTap(onBus: 0)
        
        isRecording = false
        isSpeaking = false
        
        recordFile = nil
        
        do { try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) } catch { }
    }
    
    // MARK: - Audio session
    private func configureSessionSafely() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .spokenAudio, options: [.defaultToSpeaker, .allowBluetooth])
        
        // ✅ Helps some environments return a valid SR / channels
        try? session.setPreferredSampleRate(44_100)
        try? session.setPreferredIOBufferDuration(0.01)
        
        try session.setActive(true, options: .notifyOthersOnDeactivation)
    }
    
    // MARK: - Tap (robust)
    private func startEngineTapSafely() {
        let input = audioEngine.inputNode
        
        // Always remove old tap first
        input.removeTap(onBus: 0)
        
        // ✅ Use INPUT format (correct for mic)
        let native = input.inputFormat(forBus: 0)
        
        // 1) If native is already valid, prefer it (most stable)
        if isValid(format: native) {
            installTap(using: native)
            return
        }
        
        // 2) Build a safe format using session values
        let session = AVAudioSession.sharedInstance()
        
        let sessionSR = session.sampleRate
        let preferredSR = session.preferredSampleRate
        
        let srCandidates: [Double] = [
            native.sampleRate,
            preferredSR,
            sessionSR,
            48_000,
            44_100
        ].filter { $0 > 0 }
        
        // Prefer mono for speech / simplicity, but keep 2 if that’s the only valid one
        let chCandidates: [AVAudioChannelCount] = [
            native.channelCount,
            1,
            2
        ].filter { $0 > 0 }
        
        var chosen: AVAudioFormat? = nil
        
        // Try native channels with safe SR first (non-interleaved Float32)
        for sr in srCandidates {
            for ch in chCandidates {
                if let f = AVAudioFormat(commonFormat: .pcmFormatFloat32,
                                         sampleRate: sr,
                                         channels: ch,
                                         interleaved: false),
                   isValid(format: f) {
                    chosen = f
                    break
                }
            }
            if chosen != nil { break }
        }
        
        // 3) Last resort
        if chosen == nil {
            chosen = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 1)
        }
        
        guard let tapFormat = chosen, isValid(format: tapFormat) else {
            statusMessage = "Audio format could not be created."
            return
        }
        
        installTap(using: tapFormat)
    }
    
    private func installTap(using format: AVAudioFormat) {
        let input = audioEngine.inputNode
        
        currentSampleRate = format.sampleRate
        onsetAnalyzer.reset(sampleRate: currentSampleRate, framesPerBuffer: Double(tapBufferSize))
        
        input.installTap(onBus: 0, bufferSize: tapBufferSize, format: format) { [weak self] buffer, _ in
            guard let self else { return }
            
            self.request?.append(buffer)
            self.updateLevelAndOnset(from: buffer)
            self.writeBufferToFileIfNeeded(buffer)
        }
        
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            statusMessage = "Could not start microphone."
        }
    }
    
    private func isValid(format: AVAudioFormat) -> Bool {
        return format.sampleRate > 0 && format.channelCount > 0
    }
    
    private func writeBufferToFileIfNeeded(_ buffer: AVAudioPCMBuffer) {
        guard shouldRecordToFile else { return }
        guard let url = recordURL else { return }
        
        do {
            if recordFile == nil {
                recordFile = try AVAudioFile(forWriting: url, settings: buffer.format.settings)
            }
            try recordFile?.write(from: buffer)
        } catch {
            shouldRecordToFile = false
            recordFile = nil
        }
    }
    
    // MARK: - Recognition Task
    private func startRecognitionTask(recognizer: SFSpeechRecognizer) {
        task?.cancel()
        task = nil
        
        let r = SFSpeechAudioBufferRecognitionRequest()
        r.shouldReportPartialResults = true
        
        // ✅ Only force on-device if supported, otherwise don't hard-fail
        r.requiresOnDeviceRecognition = recognizer.supportsOnDeviceRecognition
        
        request = r
        
        task = recognizer.recognitionTask(with: r) { [weak self] result, error in
            guard let self else { return }
            
            if let result {
                self.transcript = result.bestTranscription.formattedString
                self.checkExpectedPhraseMatch()
            }
            
            if let error {
                self.statusMessage = "Recognition paused: \(error.localizedDescription)"
            }
        }
    }
    
    // MARK: - Expected phrase matching
    private func checkExpectedPhraseMatch() {
        guard didMatchExpectedPhrase == false else { return }
        guard expectedWords.isEmpty == false else { return }
        
        let spoken = Self.words(from: transcript)
        guard spoken.isEmpty == false else { return }
        
        let lcs = lcsMatchCount(expected: expectedWords, spoken: spoken)
        let ratio: Float = expectedWords.isEmpty ? 0 : Float(lcs) / Float(expectedWords.count)
        let requiredCount = max(minimumMatchedWords, Int(ceil(Float(expectedWords.count) * lcsMatchRatio)))
        
        if lcs >= requiredCount || ratio >= lcsMatchRatio {
            didMatchExpectedPhrase = true
        }
    }
    
    private func lcsMatchCount(expected: [String], spoken: [String]) -> Int {
        let n = expected.count
        let m = spoken.count
        if n == 0 || m == 0 { return 0 }
        
        var prev = Array(repeating: 0, count: m + 1)
        var cur  = Array(repeating: 0, count: m + 1)
        
        for i in 1...n {
            cur[0] = 0
            for j in 1...m {
                if fuzzyEqual(expected[i - 1], spoken[j - 1]) {
                    cur[j] = prev[j - 1] + 1
                } else {
                    cur[j] = max(prev[j], cur[j - 1])
                }
            }
            prev = cur
        }
        return prev[m]
    }
    
    private func fuzzyEqual(_ a: String, _ b: String) -> Bool {
        if a == b { return true }
        
        let la = a.count
        let lb = b.count
        let minLen = min(la, lb)
        
        if minLen >= 3 {
            let pref = commonPrefixLength(a, b)
            let need = max(3, Int(round(Double(minLen) * 0.60)))
            if pref >= need { return true }
        }
        
        let d = levenshtein(a, b, cap: 2)
        if minLen <= 4 { return d <= 1 }
        return d <= 2
    }
    
    private func commonPrefixLength(_ a: String, _ b: String) -> Int {
        let aa = Array(a)
        let bb = Array(b)
        let n = min(aa.count, bb.count)
        var k = 0
        while k < n {
            if aa[k] != bb[k] { break }
            k += 1
        }
        return k
    }
    
    private func levenshtein(_ s: String, _ t: String, cap: Int) -> Int {
        if s == t { return 0 }
        let a = Array(s)
        let b = Array(t)
        let n = a.count
        let m = b.count
        if n == 0 { return min(m, cap + 1) }
        if m == 0 { return min(n, cap + 1) }
        
        if abs(n - m) > cap { return cap + 1 }
        
        var prev = Array(0...m)
        var cur = Array(repeating: 0, count: m + 1)
        
        for i in 1...n {
            cur[0] = i
            var rowMin = cur[0]
            
            for j in 1...m {
                let cost = (a[i - 1] == b[j - 1]) ? 0 : 1
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                rowMin = min(rowMin, cur[j])
            }
            
            if rowMin > cap { return cap + 1 }
            prev = cur
        }
        return prev[m]
    }
    
    private static func words(from input: String) -> [String] {
        let lower = input.lowercased()
        let cleaned = lower
            .replacingOccurrences(of: "[^a-z\\s']", with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        
        if cleaned.isEmpty { return [] }
        return cleaned.split(separator: " ").map { String($0) }
    }
    
    // MARK: - Level + Onset (Float32 + Int16)
    private func updateLevelAndOnset(from buffer: AVAudioPCMBuffer) {
        let n = Int(buffer.frameLength)
        if n == 0 { return }
        
        var rms: Float = 0
        
        if let floatCh = buffer.floatChannelData?.pointee {
            var sum: Float = 0
            for i in 0..<n {
                let s = floatCh[i]
                sum += s * s
            }
            rms = sqrt(sum / Float(n))
        } else if let int16Ch = buffer.int16ChannelData?.pointee {
            var sum: Float = 0
            let denom = Float(Int16.max)
            for i in 0..<n {
                let s = Float(int16Ch[i]) / denom
                sum += s * s
            }
            rms = sqrt(sum / Float(n))
        } else {
            return
        }
        
        let normalized = min(max(rms * 18, 0), 1)
        let metrics = onsetAnalyzer.process(rms: rms)
        
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            
            self.rawRMS = rms
            self.audioLevel = normalized
            self.voicing = normalized
            self.isSpeaking = normalized > self.speakingThreshold
            
            if let m = metrics {
                self.onsetScore = m.score
                self.onsetKind = m.kind
                self.onsetVerdict = m.verdict
                self.onsetHint = m.hint
                self.onsetConfidence = m.confidence
                self.onsetDebug = m.debug
            }
        }
    }
}

